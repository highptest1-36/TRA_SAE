TRA-SAE — Expert Systems (Wiley) LaTeX source (lean, Overleaf-free friendly)
===========================================================================
Main file : TRA_SAE_ExpertSystems_Main.tex   (class: USG.cls, Wiley NJD)
Compiler  : pdfLaTeX   (Overleaf: Menu -> Compiler -> pdfLaTeX)
Sequence  : pdflatex -> bibtex -> pdflatex -> pdflatex
Bib       : references.bib  (style WileyNJD-APA.bst)
Figures   : fig1_pipeline.png, fig_stage_accuracy.png, fig_vs_baselines.png
Note      : unused Wiley sample images removed to keep the project small;
            only the Wiley + ORCID logos are kept (used on the title page).
